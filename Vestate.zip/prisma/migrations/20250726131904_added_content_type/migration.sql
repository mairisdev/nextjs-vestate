-- AlterEnum
ALTER TYPE "ContentType" ADD VALUE 'BLOG';
