-- AlterTable
ALTER TABLE "AgentReview" ADD COLUMN     "rating" INTEGER NOT NULL DEFAULT 5;
