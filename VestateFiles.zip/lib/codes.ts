type CodeEntry = { code: string; expires: number }

const globalForCodes = globalThis as unknown as { codes?: Map<string, CodeEntry> }

export const codes = globalForCodes.codes ??= new Map()
