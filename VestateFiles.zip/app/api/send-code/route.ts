import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { randomInt } from "crypto"

export async function POST(req: Request) {
  const { email, phone } = await req.json()

  if (!email || !phone) {
    return NextResponse.json({ error: "Nepieciešams e-pasts un tālrunis!" }, { status: 400 })
  }

  const code = randomInt(100000, 999999).toString()
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000) // 15 min

  try {
    await prisma.accessRequest.upsert({
      where: { email },
      update: { code, phone, expiresAt },
      create: { email, phone, code, expiresAt },
    })

    // Notificē lietotāju
    await fetch("/api/send-access-request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, phone, code }),
    })

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Kļūda saglabājot/verificējot pieprasījumu:", error)
    return NextResponse.json({ error: "Kļūda apstrādājot pieprasījumu" }, { status: 500 })
  }
}
