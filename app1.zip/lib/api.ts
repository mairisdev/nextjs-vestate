export async function getFooterContent() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/api/footer`, { cache: 'no-store' });
  return res.json();
}
