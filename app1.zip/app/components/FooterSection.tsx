"use client"

import {
  Facebook,
  Instagram,
  Linkedin,
  Phone,
  Mail,
  MapPin,
} from "lucide-react"
import Link from "next/link"

const navLinks = [
  { label: "Sākums", href: "/" },
  { label: "Par mums", href: "/par-mums" },
  { label: "Īpašumi", href: "/ipasumi" },
  { label: "Kontakti", href: "/kontakti" },
]

const services = [
  "Īpašumu pārdošana",
  "Noma un izīrēšana",
  "Konsultācijas",
  "Vērtējumi",
]

const contact = {
  phone: "+371 28446677",
  email: "info@vestate.lv",
  address: "Dominas biroji, Ieriķu iela 3, Rīga, LV-1084",
}

const socialLinks = [
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
]

export default function Footer() {
  return (
    <footer className="bg-[#00332D] text-white pt-16 pb-8 px-4 md:px-12">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10">
        <div>
          <h2 className="text-2xl font-bold mb-4">SIA Vestate</h2>
          <p className="text-sm text-gray-300">
            Profesionāli nekustamā īpašuma pakalpojumi Rīgā un visā Latvijā.
          </p>
        </div>

        <div>
          <h3 className="font-semibold mb-4 text-white">Lapas karte</h3>
          <ul className="space-y-2 text-sm text-gray-300">
            {navLinks.map(({ label, href }) => (
              <li key={href}>
                <Link href={href} className="hover:text-[#77D4B4] transition">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-semibold mb-4 text-white">Pakalpojumi</h3>
          <ul className="space-y-2 text-sm text-gray-300">
            {services.map((service, i) => (
              <li key={i}>{service}</li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-semibold mb-4 text-white">Kontaktinformācija</h3>
          <ul className="space-y-3 text-sm text-gray-300">
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4" />
              <a href={`tel:${contact.phone}`} className="hover:text-[#77D4B4] transition">{contact.phone}</a>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              <a href={`mailto:${contact.email}`} className="hover:text-[#77D4B4] transition">{contact.email}</a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin className="w-4 h-4 mt-1" />
              <span>{contact.address}</span>
            </li>
          </ul>

          <div className="flex gap-4 mt-6">
            {socialLinks.map(({ icon: Icon, href, label }) => (
              <a key={label} href={href} aria-label={label} className="hover:text-[#77D4B4] transition">
                <Icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="border-t border-white/10 mt-12 pt-6 text-sm text-gray-400 text-center">
        © {new Date().getFullYear()} Vestate. Visas tiesības aizsargātas. Izstrāde:{" "}
        <a
          href="https://facebook.com/MairisDigital"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#77D4B4] hover:underline"
        >
          MairisDigital
        </a>
      </div>
    </footer>
  )
}
