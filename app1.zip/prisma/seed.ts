import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function main() {
  await prisma.footerContent.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      companyName: "SIA Vestate",
      description: "Profesionāli nekustamā īpašuma pakalpojumi Rīgā un visā Latvijā.",
      phone: "+371 28446677",
      email: "info@vestate.lv",
      address: "Dominas biroji, Ieriķu iela 3, Rīga, LV-1084",
      facebook: "#",
      instagram: "#",
      linkedin: "#",
    },
  })

  console.log("✅ Seed izpildīts.")
}

main()
  .catch((e) => {
    console.error("❌ Kļūda seed laikā:", e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
