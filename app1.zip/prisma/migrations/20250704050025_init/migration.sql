-- AlterTable
ALTER TABLE "NavigationSettings" ADD COLUMN     "dropdownItems" JSONB;
