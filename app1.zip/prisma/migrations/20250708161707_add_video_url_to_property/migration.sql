-- AlterTable
ALTER TABLE "Property" ADD COLUMN     "videoUrl" TEXT;
