-- AlterTable
ALTER TABLE "Property" ADD COLUMN     "propertyProject" TEXT;
